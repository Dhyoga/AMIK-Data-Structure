// Java program to illustrate
// Java.util.HashMap
import java.util.LinkedHashMap;
public class LHMContainsKey{
	public static void main(String[] args){
		// Create an empty hash map
		LinkedHashMap<String, Integer> map = new LinkedHashMap<>();
		// Add elements to the map
		map.put("Budi", 70);
		map.put("Dewi", 90);
		map.put("Eddy", 80);
		map.put("Budi", 70);
		// Print size and content
		System.out.println("Size of map is: "
			+ map.size());
		System.out.println(map);
		// Check if a key is present and if
		// present, print value
		if (map.containsKey("Budi")) {
			Integer a = map.get("Budi");
			System.out.println("value for key"
				+ " \"Budi\" is: " + a);
		}
	}
}
/*
Size of map is: 3
{Budi=70, Dewi=90, Eddy=80}
value for key "Budi" is: 70
*/