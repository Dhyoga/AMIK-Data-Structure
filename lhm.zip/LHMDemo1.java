// Java program to demonstrate working of LinkedHashMap
import java.util.*;
public class LHMDemo1 {

	public static void main(String a[]){
		// create an instance of LinkedHashMap
		LinkedHashMap<String, String> lhm
			= new LinkedHashMap<String, String>();
		// Add mappings using put method
		lhm.put("one", "practice.learnjava.org");
		lhm.put("two", "code.learnjava.org");
		lhm.put("four", "quiz.learnjava.org");
		// It prints the elements in same order
		// as they were inserted
		System.out.println(lhm);
		System.out.println("Getting value for key 'one': "
			+ lhm.get("one"));
		System.out.println("Size of the map: "
			+ lhm.size());
		System.out.println("Is map empty? "
			+ lhm.isEmpty());
		System.out.println("Contains key 'two'? "
			+ lhm.containsKey("two"));
		System.out.println(
			"Contains value 'practice.learn"
			+ "java.org'? "
			+ lhm.containsValue("practice"
			+ ".learnjava.org"));
		System.out.println("delete element 'one': "
			+ lhm.remove("one"));
		// print mappings to the console
		System.out.println("Mappings of LinkedHashMap : "
			+ lhm);
	}
}
/*
{one=practice.learnjava.org, two=code.learnjava.org, four=quiz.learnjava.org}
Getting value for key 'one': practice.learnjava.org
Size of the map: 3
Is map empty? false
Contains key 'two'? true
Contains value 'practice.learnjava.org'? true
delete element 'one': practice.learnjava.org
Mappings of LinkedHashMap : {two=code.learnjava.org, four=quiz.learnjava.org}
*/