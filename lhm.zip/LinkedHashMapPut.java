// Java program to demonstrate adding
// elements to a LinkedHashMap
import java.util.*;
class LinkedHashMapPut {
	public static void main(String args[]){
		// Initialization of a LinkedHashMap
		// using Generics
		LinkedHashMap<Integer, String> hm1
			= new LinkedHashMap<Integer, String>();
		// Add mappings using
		// put() method
		hm1.put(3, "Structure");
		hm1.put(2, "For");
		hm1.put(1, "Data");
		hm1.put(3, "Structure2");
		// print mappings to the console
		System.out.println("Mapping of LinkedHashMap : \n"
			+ hm1);
	}
}
/*
Mapping of LinkedHashMap :
{3=Structure, 2=For, 1=Data}
*/