// Java program to demonstrate the
// HashMap(int initialCapacity)
// constructor
import java.io.*;
import java.util.*;
class LHMInitCapacity{
	public static void main(String args[]){
		// No need to mention the
		// using Generics
		Map<Integer, String> lhm1 = new LinkedHashMap<>();//1);

		LinkedHashMap<Integer, String> lhm2
			= new LinkedHashMap<Integer, String>(2);
		// Add Elements using put method
		lhm1.put(1, "one");
		lhm1.put(2, "two");
		lhm1.put(3, "three");
		lhm2.put(4, "four");
		lhm2.put(5, "five");
		lhm2.put(6, "six");
		System.out.println
			("Mapping of LinkedHashMap lhm1 are : \n"+ lhm1);
		System.out.println
			("Mapping of LinkedHashMap lhm2 are : \n"+ lhm2);
	}
}
/*
Mapping of LinkedHashMap lhm1 are :
{1=one, 2=two, 3=three}
Mapping of LinkedHashMap lhm2 are :
{4=four, 5=five, 6=six}
*/