// Java Program illustrating HashMap class methods().  
// entrySet(), getOrDefault(), replace(), putIfAbsent 
import java.util.*; 
public class LHMEntrySet 
{ 
    public static void main(String args[]) 
    { 
        // Creation of HashMap 
        LinkedHashMap<String, String> hm = new LinkedHashMap<>(); 
  
        // Adding values to HashMap as ("keys", "values") 
        hm.put("Language", "Java"); 
        hm.put("Code", "HashMap"); 
        hm.put("Learn", "More"); 
  
        // .entrySet() returns all the keys with 
		// their values present in Hashmap 
        Set<Map.Entry<String, String>> mappinghm = hm.entrySet(); 
        System.out.println
			("Set of Keys and Values using entrySet() : \n"
			+ mappinghm); 
        System.out.println(); 
  
        // Using .getOrDefault to access value 
        // Here it is Showing Default value as key - "Code" 
		// was already present 
        System.out.println("Using .getorDefault : \n" 
            + hm.getOrDefault("Code","javaArticle")); 
  
        // Here it is Showing set value as key - "Search" 
		// was not present 
        System.out.println("Using .getorDefault : \n"
            + hm.getOrDefault("Search","javaArticle")); 
		System.out.println(); 
  
        // .replace() method replacing value of key "Learn" 
        hm.replace("Learn", "Methods"); 
        System.out.println("working of .replace() : \n"
			+ mappinghm); 
        System.out.println(); 
  
        /* .putIfAbsent() method is placing a new key-value 
            as they were not present initially*/
        hm.putIfAbsent("cool", "HashMap methods"); 
        System.out.println("working of .putIfAbsent() : \n"
			+ mappinghm); 
  
        /* .putIfAbsent() method is not doing anything 
            as key-value were already present */
        hm.putIfAbsent("Code", "With_JAVA"); 
        System.out.println("working of .putIfAbsent() : \n"
			+ mappinghm); 
  
    } 
} 
/*
Set of Keys and Values using entrySet() :
[Language=Java, Learn=More, Code=HashMap]

Using .getorDefault :
HashMap
Using .getorDefault :
javaArticle

working of .replace() :
[Language=Java, Learn=Methods, Code=HashMap]

working of .putIfAbsent() :
[Language=Java, cool=HashMap methods, Learn=Methods, Code=HashMap]
working of .putIfAbsent() :
[Language=Java, cool=HashMap methods, Learn=Methods, Code=HashMap]
*/