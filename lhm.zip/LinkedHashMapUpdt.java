// Java program to demonstrate
// changing/updating of LinkedHashMap
import java.util.*;
class LinkedHashMapUpdt {
	public static void main(String args[]){
		// Initialization of a LinkedHashMap
		// using Generics
		LinkedHashMap<Integer, String> hm
			= new LinkedHashMap<Integer, String>();
		// Insert mappings using put() method
		hm.put(3, "Structure");
		hm.put(2, "Structure");
		hm.put(1, "Structure");
		// print mappings to the console
		System.out.println("Initial map : " + hm);
		// Update the value with key 2
		hm.put(2, "For");
		hm.put(3, "Data");
		// print the updated map
		System.out.println("Updated Map : " + hm);
	}
}
/*
Initial map : {3=Structure, 2=Structure, 1=Structure}
Updated Map : {3=Data, 2=For, 1=Structure}
*/