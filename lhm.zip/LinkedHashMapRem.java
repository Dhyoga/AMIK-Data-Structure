// Java program to demonstrate the
// removing of elements from LinkedHashMap
import java.util.*;
class LinkedHashMapRem {
	public static void main(String args[]){
		// Initialization of a LinkedHashMap
		// using Generics
		LinkedHashMap<Integer, String> hm
			= new LinkedHashMap<Integer, String>();
		// Inserting the Elements
		// using put() method
		hm.put(2, "For");
		hm.put(3, "Data");
		hm.put(1, "Structure");
		hm.put(4, "IF-AZ");
		// print the mappings to the console
		System.out.println("Initial Map : " + hm);
		// Remove the mapping with Key 4
		hm.remove(5);
		// print the updated map
		System.out.println("Updated Map : " + hm);
	}
}
/*
Initial Map : {2=For, 3=Data, 1=Structure, 4=IF-AZ}
Updated Map : {2=For, 3=Data, 1=Structure}
*/