// InitObjectArray.java
// Initializing the elements of an array 
// to default values of null.
import java.util.*;
 public class InitObjectArray {
    public static void main(String[] args) {
		Object[] array=new Integer[10];
		// column headings
        System.out.printf("%s%8s%n", "Index", "Value"); 
		try{
			for(int cc=0;cc<array.length;cc++) {   
				if(array[cc]==null) array[cc]=0;
				System.out.printf("%s%8d%n", cc, array[cc]); 
			}
		}catch(MissingFormatArgumentException e){
			System.out.println(e);}
    } 
} // end class InitObjectArray