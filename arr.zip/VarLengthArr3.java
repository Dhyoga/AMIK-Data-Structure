class VarLengthArr3 {
	public static void main(String... args) {
		printArr();
	}
	static void printArr(){
		String[] var={"hello","world"};
		System.out.println("var length: "+var.length);
		int len=var.length;
		len++;var=new String[len];var[len-1]="!";
		for(int i=0;i<len;i++)
			System.out.print(var[i]+" ");
		System.out.println();
	}
	static String[] copyArr(String[] ori,String[] cpy){
		for(int i=0;i<ori.length;i++)
			cpy[i]=ori[i];
		return cpy;
	}
}
/*
*/
