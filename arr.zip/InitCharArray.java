// InitCharArray.java
// Initializing the elements of an array 
// to default values of blank (\b).
import java.util.*;
public class InitCharArray {
    public static void main(String[] args) {
		char[] array=new char[10];
		// column headings
        System.out.printf("%s%8s%n", "Index", "Value"); 
		try{
			for(int cc=0;cc<array.length;cc++) {   
				if(array[cc]==' ') array[cc]='\b';
				System.out.printf("%s%8c%n", cc, array[cc]); 
			}
		}catch(MissingFormatArgumentException e){
			System.out.println(e);}
    } 
} // end class InitCharArray