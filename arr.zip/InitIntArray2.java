// InitIntArray2.java
// Initializing the elements of an array 
// to default values of zero.
 public class InitIntArray2 {
	 public static void init(int size){
		int[] array=new int[size];
		// column headings
        System.out.printf("%s%8s%n", "Index", "Value"); 
		for(int cc=0;cc<array.length;cc++)    
			System.out.printf("%s%8s%n", cc, array[cc]); 
     } 
     public static void main(String[] args) {
		init(10);
	 }
 } // end class InitIntArray2