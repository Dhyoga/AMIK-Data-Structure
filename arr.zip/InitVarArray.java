// InitVarArray.java
// Initializing the elements of an array 
// to default values of null.
public class InitVarArray {
    public static void main(String... array) {
		// column headings
		if(array.length==0)
        System.out.println("type n arguments:");
		else
        System.out.printf("%s%8s%n", "Index", "Value"); 
		for(int cc=0;cc<array.length;cc++) {   
			System.out.printf("%s\t%8s%n", cc, array[cc]); 
		}
    } 
 } // end class InitVarArray 