// InitIntArray.java
// Initializing the elements of an array to 
// default values of zero.
 public class InitIntArray {
    public static void main(String[] args) {
		int[] array=new int[10];
		// column headings
        System.out.printf("%s%8s%n", "Index", "Value"); 
		for(int cc=0;cc<array.length;cc++)    
			System.out.printf("%s%8s%n", cc, array[cc]); 
    } 
 } // end class InitIntArray