class VarLengthArr2 {
	public static void main(String[] args) {
		printArg(args);
	}
	static void printArg(String[] par){
		int len=par.length;
		if(len!=0) {
			System.out.println("argument:");
			for(int i=0;i<len;i++)
				System.out.print(par[i]+" ");
		} else System.out.print("no argument");
		System.out.println("\npar length: "+len);
	}
}
/*
Contoh eksekusi-1:
java VarLengthArr2
hasil:
no argument
==================
Contoh eksekusi-2:
java VarLengthArr2 1 2 3 4 5 6 7 8 9 0 100
hasil:
argument:
1 2 3 4 5 6 7 8 9 0 100
par length: 11
*/
