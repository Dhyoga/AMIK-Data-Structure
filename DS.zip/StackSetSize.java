// Java program to demonstrate
// setSize() method for Integer value
import java.util.*;
public class StackSetSize { // + trimToSize, capacity
	public static void main(String[] argv){
		try {
			// Creating object of Stack<Integer>
			Stack<Integer>
			stack = new Stack<Integer>();
			// adding element to stack
			stack.add(10);
			stack.add(20);
			stack.add(30);
			stack.add(40);
			// Print the Stack
			System.out.println("Stack: " + stack);
			// Print the current size of Stack
			System.out.println("Current size of Stack: "
				+ stack.size());
			// Print the current capacityze of Stack
			System.out.println("Current capacity of Stack: "
				+ stack.capacity());
			System.out.println("trimToSize");
			stack.trimToSize();
			System.out.println("New capacity of Stack: "
				+ stack.capacity());
			System.out.println("setSize(6)");
			// Change the size to 6
			stack.setSize(6);
			// Print the current size of Stack
			System.out.println("New size of Stack: "
				+ stack.size());
			//stack.ensureCapacity(3);
			stack.trimToSize();
			System.out.println("New capacity of Stack: "
				+ stack.capacity());
		}catch (Exception e) {
			System.out.println("Exception thrown : " + e);
		}
	}
}
/*
Stack: [10, 20, 30, 40]
Current size of Stack: 4
Current capacity of Stack: 10
trimToSize
New capacity of Stack: 4
setSize(6)
New size of Stack: 6
New capacity of Stack: 6
*/
