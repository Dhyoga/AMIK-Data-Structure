// Java code to illustrate setElementAt()
import java.io.*;
import java.util.*;
public class StackSetElm { // + get
	public static void main(String args[]){
		// Creating an empty Stack
		Stack<String> stack = new Stack<String>();
		// Use add() method to add elements in the stack
		stack.add("Welcomes");
		stack.add("To");
		stack.add("Data");
		stack.add("Structure");
		stack.add("IF-A");
		// Displaying the linkedstack
		System.out.println("Stack: \n"
			+ stack);
		String t = "Base";
		System.out.println(stack.get(3) + 
			" replaced with " + t);
		stack.setElementAt(t, 3);
		// Displaying the modified linkedstack
		System.out.println("The new Stack is: \n"
			+ stack);
	}
}
/*
Stack:
[Welcomes, To, Data, Structure, IF-A]
Structure replaced with Base
The new Stack is:
[Welcomes, To, Data, Base, IF-A]
*/
