// Java code to illustrate size()
import java.util.*;
public class StackSize { // + empty + removeAll
	public static void main(String args[]){
		// Creating an empty Stack
		Stack<String> stack = new Stack<String>();

		// Use add() method to add elements into the Stack
		stack.add("Welcome");
		stack.add("To");
		stack.add("Data");
		stack.add("Structure");
		stack.add("IF-A");
		// Displaying the Stack
		System.out.println("Stack: \n" + stack);
		// Displaying the size of Stack
		System.out.println("The size is: " + stack.size());
		System.out.println("Stack is empty: " + stack.empty());
		System.out.println("removeAll");
		stack.removeAll(stack);
		// Displaying the size of Stack after
		System.out.println("The size after is: " + stack.size());
		System.out.println("Stack is empty: " + stack.empty());
	}
}
/*
Stack:
[Welcome, To, Data, Structure, IF-A]
The size is: 5
Stack is empty: false
removeAll
The size after is: 0
Stack is empty: true
*/
