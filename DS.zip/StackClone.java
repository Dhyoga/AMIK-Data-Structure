// Java code to illustrate clone()
import java.util.*;
public class StackClone { // + equals
	public static void main(String args[]){
		// Creating an empty Stack
		Stack<String> stack = new Stack<String>();
		// Use add() method to add elements into the Stack
		stack.add("Welcome");
		stack.add("To");
		stack.add("Data");
		stack.add("Structure");
		stack.add("IF-A");

		// Displaying the Stack
		System.out.println("Stack: \n" + stack);
		// Creating another Stack to copy
		Object copy_Stack = stack.clone();
		// Displaying the copy of Stack
		System.out.println("The cloned Stack is: \n"
			+ copy_Stack);
		System.out.println("Is equal: " 
                + stack.equals(copy_Stack));
	}
}
/*
Stack:
[Welcome, To, Data, Structure, IF-A]
The cloned Stack is:
[Welcome, To, Data, Structure, IF-A]
Is equal: true
*/
