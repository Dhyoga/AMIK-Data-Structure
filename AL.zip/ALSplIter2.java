// Java Program Demonstrate spliterator()
// method of ArrayList
import java.util.*;
public class ALSplIter2{//user
public static void main(String[] args)
{
// create an ArrayList which contains
// user details from user class
ArrayList<user> list = new ArrayList<user>();
// Add emails to list
list.add(new user("Aman", 24));
list.add(new user("Suradi", 23));
list.add(new user("Amar", 24));
list.add(new user("Kamal", 22));
// create Spliterator of ArrayList
// using spliterator() method
Spliterator<user> users = list.spliterator();
// print result from Spliterator
System.out.println("list of Emails:");
// forEachRemaining method of Spliterator
users.forEachRemaining((n) -> print(n));
}
public static void print(user u)
{
System.out.println("User name : " + u.name
+ " and user age: " + u.age);
}
}
// create a user class
class user {
String name;
int age;
user(String name, int age)
{
this.name = name;
this.age = age;
}
}
/*
list of Emails:
User name : Aman and user age: 24
User name : Suradi and user age: 23
User name : Amar and user age: 24
User name : Kamal and user age: 22
*/