// Java program for reversing an arraylist
import java.io.*;
import java.util.*;
public class ReverseArrayList3{
public static void main(String[] args)
{
// Declaring arraylist without any initial size
ArrayList<Integer> arrayli = new ArrayList<Integer>();
// Appending elements at the end of the list
arrayli.add(new Integer(39));
arrayli.add(new Integer(14));
arrayli.add(new Integer(78));
arrayli.add(new Integer(43));
arrayli.add(new Integer(25));
System.out.println("Elements before reversing: ");
printElements(arrayli);
System.out.println();
// Collections.reverse method takes a list as a
// parameter and returns the reversed list
Collections.reverse(arrayli);
System.out.println("Elements after reversing: ");
printElements(arrayli);
System.out.println();
}
// Iterate through all the elements and print
public static void printElements(ArrayList<Integer> alist)
{
for (int i = 0; i < alist.size(); i++) {
System.out.print(alist.get(i) + " ");
}
}
}
/*
Elements before reversing:
39 14 78 43 25
Elements after reversing:
25 43 78 14 39
*/