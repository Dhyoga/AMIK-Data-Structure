// Program Demonstrate retainAll() method With
// Collection different then ArrayList as a parameter of the method
import java.util.*;
public class ALRetainAll2{
public static void main(String[] args)
{
// Creating an empty array list
HashSet<String> bags = new HashSet<String>();
// Add values in the bags Set.
bags.add("pen");
bags.add("ink");
bags.add("paper");
//bags.clear();
// Creating another empty array list
ArrayList<String> boxes = new ArrayList<String>();
// Add values in the boxes list.
boxes.add("pen");
boxes.add("paper");
boxes.add("books");
boxes.add("rubber");
boxes.add("ink");
// Before Applying method print both list and set.
System.out.println("Bags Contains :" + bags);
System.out.println("Boxes Contains :" + boxes);
// Apply retainAll() method to boxes passing bags as parameter
boxes.retainAll(bags);
// Displaying both the lists after operation
System.out.println("After Applying retainAll()" +
" method to Boxes");
System.out.println("Bags Contains :" + bags);
System.out.println("Boxes Contains :" + boxes);
}
}
/*
Bags Contains :[paper, ink, pen]
Boxes Contains :[pen, paper, books, rubber, ink]
After Applying retainAll() method to Boxes
Bags Contains :[paper, ink, pen]
Boxes Contains :[pen, paper, ink]
*/