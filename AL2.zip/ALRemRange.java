import java.util.*;

public class ALRemRange extends ArrayList<Integer> {
	public static void main(String[] args){
		// create an empty array list
		ALRemRange arr = new ALRemRange();
		// use add() method to add values in the list
		arr.add(1);//idx:0
		arr.add(2);//idx:1
		arr.add(3);//idx:2
		arr.add(4);//idx:3
		System.out.println("The list before using removeRange:" + arr);
		try{//removeRange(from, to exclusive)
//			arr.removeRange(3, 4);//exclusive, only last elm: deleted (Ok)
//			arr.removeRange(3, 3);//nothing happenned: Ok
//			arr.removeRange(3, 2);//why 1 copy (3), instead of error message
//			arr.removeRange(3, 1);//why 2 copies (2 & 3), no error message
			arr.removeRange(3, 0);//why 3 copies (1, 2 & 3), no error message
		}catch(Exception e){System.out.println(e);}
		System.out.println("The list after using removeRange:" + arr);
	}
}
