// Program to illustrate error thrown by retainAll() method
import java.util.*;
public class ALRetainAll3{
public static void main(String[] args)
{
// Creating an empty array list
ArrayList<Integer> list1 = null;
/// Creating another empty array list
ArrayList<String> list2 = new ArrayList<String>();
// Add values in the list2 list.
list2.add("pen");
list2.add("paper");
list2.add("books");
list2.add("rubber");
// Before Applying method print both lists
System.out.println("list1 Contains :" + list1);
System.out.println("list2 Contains :" + list2);
// Apply retainAll() method to list2 passing list1 as parameter
try{
list2.retainAll(list1);
}catch(Exception e){System.out.println(e);}
// Displaying both the lists after operation
System.out.println("After Applying retainAll()"+
" method to list2");
System.out.println("list1 Contains :" + list1);
System.out.println("list2 Contains :" + list2);
}
}
/*
list1 Contains :null
list2 Contains :[pen, paper, books, rubber]
java.lang.NullPointerException
After Applying retainAll() method to list2
list1 Contains :null
list2 Contains :[pen, paper, books, rubber]
*/