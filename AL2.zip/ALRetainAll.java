// Java code to illustrate retainAll() method
import java.util.ArrayList;
public class ALRetainAll{
public static void main(String[] args)
{
// Creating an empty array list
ArrayList<String> bags = new ArrayList<String>();
// Add values in the bags list.
bags.add("pen");
bags.add("pencil");
bags.add("paper");
//bags.clear();
// Creating another array list
ArrayList<String> boxes = new ArrayList<String>();
// Add values in the boxes list.
boxes.add("pen");
boxes.add("paper");
boxes.add("books");
boxes.add("rubber");
// Before Applying method print both lists
System.out.println("Bags Contains :" + bags);
System.out.println("Boxes Contains :" + boxes);
// Apply retainAll() method to boxes passing bags as parameter
boxes.retainAll(bags);
// Displaying both the lists after operation
System.out.println("After Applying retainAll()"+
" method to Boxes");
System.out.println("Bags Contains :" + bags);
System.out.println("Boxes Contains :" + boxes);
}
}
/*
Bags Contains :[pen, pencil, paper]
Boxes Contains :[pen, paper, books, rubber]
After Applying retainAll() method to Boxes
Bags Contains :[pen, pencil, paper]
Boxes Contains :[pen, paper]
*/