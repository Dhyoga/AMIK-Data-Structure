// Java program for reversing an arraylist
import java.io.*;
import java.util.*;
class Employee {
int empID;
String empName;
String deptName;
// Constructor for initializing the class variables
public Employee(int empID, String empName, String deptName)
	{
	this.empID = empID;
this.empName = empName;
this.deptName = deptName;
}
}
public class ReverseArrayList4{
public static void main(String[] args)
{
// Declaring arraylist without any initial size
ArrayList<Employee> arrayli = new ArrayList<Employee>();
// Creating user defined objects
Employee emp1 = new Employee(123, "Rani", "Facilities");
Employee emp2 = new Employee(124, "Laksmi", "Transport");
Employee emp3 = new Employee(125, "Royani", "Packing");
// Appending all the objects for arraylist
arrayli.add(emp1);
arrayli.add(emp2);
arrayli.add(emp3);
System.out.print("Elements before reversing: ");
printElements(arrayli);
System.out.println();
// Collections.reverse method takes a list as a
// parameter and returns the reversed list
Collections.reverse(arrayli);
System.out.print("Elements after reversing: ");
printElements(arrayli);
System.out.println();
}
// Iterate through all the elements and print
public static void printElements(ArrayList<Employee> alist)
{
for (int i = 0; i < alist.size(); i++) {
System.out.print("\n EmpID:" + alist.get(i).empID +
", EmpName:" + alist.get(i).empName + ", Department:" +
alist.get(i).deptName);
}
}
}
/*
Elements before reversing:
 EmpID:123, EmpName:Rani, Department:Facilities
 EmpID:124, EmpName:Laksmi, Department:Transport
 EmpID:125, EmpName:Royani, Department:Packing
Elements after reversing:
 EmpID:125, EmpName:Royani, Department:Packing
 EmpID:124, EmpName:Laksmi, Department:Transport
 EmpID:123, EmpName:Rani, Department:Facilities
 */