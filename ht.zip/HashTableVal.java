// Java code illustrating values() method
import java.util.*;
class HashTableVal {
	public static void main(String[] arg){
		// creating a hash table
		Hashtable<Integer, String> h =
			new Hashtable<Integer, String>();
		h.put(3, "Data");
		h.put(2, "Structure");
		h.put(1, "IF-AZ");
		// creating set view for hash table
		Set s = h.entrySet();
		System.out.println("collection values: " + s);
		// checking collection view of values
		System.out.println("collection values: " + h.values());
	}
}
//collection values: [Data, Structure, IF-AZ]