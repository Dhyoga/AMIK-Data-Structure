// Java code illustrating size() method
import java.util.*;
class HashTableSize {
	public static void main(String[] arg){
		// creating a hash table
		Hashtable<String, Integer> marks =
			new Hashtable<String, Integer>();
		System.out.println("Size is: " + marks.size());
		// enter name/marks pair
		marks.put("capuchino", new Integer(345));
		marks.put("moccachino", new Integer(245));
		marks.put("coffee", new Integer(490));
		marks.put("chocolatte", new Integer(365));
		marks.put("coffeelate", new Integer(435));
		System.out.println("Hash table:\n" + marks);
		// size of hash table
		System.out.println("Size is: " + marks.size());
	}
}
/*
Hash table:
{capuchino=345, coffeelate=435, chocolatte=365, coffee=490, moccachino=245}
Size is: 5
*/