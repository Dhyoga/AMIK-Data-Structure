import java.util.*; 
  
public class HTCompIfAbs { 
  
    // Main method 
    public static void main(String[] args) 
    { 
  
        // create a table and add some values 
        Map<String, Integer> table = new Hashtable<>(); 
        table.put("Pen", 10); 
        table.put("Book", 500); 
        table.put("Clothes", 400); 
        table.put("Mobile", 5000); 
  
        // print map details 
        System.out.println("hashTable: \n"
                           + table.toString()); 
        System.out.println("put 2 new values if absent:");  
        // provide value for new key which is absent 
        // using computeIfAbsent method 
		table.computeIfAbsent("newPen", k -> 600); 
        table.computeIfAbsent("newBook", k -> 800); 
  
        // print new mapping 
        System.out.println("new hashTable: \n"
                           + table); 
        System.out.println("put new duplicate:");  
        table.computeIfAbsent("newBook", k -> 850); 
  
        // print new mapping 
        System.out.println("new hashTable: \n"
                           + table); 
    } 
} 
/*
hashTable:
{Book=500, Mobile=5000, Pen=10, Clothes=400}
put 2 new values if absent:
new hashTable:
{newPen=600, Book=500, newBook=800, Mobile=5000, Pen=10, Clothes=400}
put new duplicate:
new hashTable:
{newPen=600, Book=500, newBook=800, Mobile=5000, Pen=10, Clothes=400}
*/