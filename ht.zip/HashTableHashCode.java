// Java code illustrating hashCode() method
import java.util.*;
class HashTableHashCode {
	public static void main(String[] arg){
		// creating a hash table
		Hashtable<Integer, String> h =
			new Hashtable<Integer, String>();
		h.put(3, "Data");
		h.put(2, "Structure");
		h.put(1, "IF-AZ");
		// obtaining hash code
		System.out.println("hash code is: " + h.hashCode());
		Enumeration e = h.elements();
		System.out.println("display values:");
		while (e.hasMoreElements()) {
			System.out.print(e.nextElement()+"\t");
//			System.out.print(e.nextElement().hashCode()+"\t");
		}System.out.println();
	}
}
//hash code is: -2074810366