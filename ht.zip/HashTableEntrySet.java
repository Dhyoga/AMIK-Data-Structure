// Java code illustrating entreysent() method
import java.util.*;
class HashTableEntrySet {
	public static void main(String[] arg){
		// creating a hash table
		Hashtable<Integer, String> h =
			new Hashtable<Integer, String>();
		h.put(3, "Data");
		h.put(2, "Structure");
		h.put(1, "IF-AZ");
		h.put(1, "IF-AZ");
		System.out.println("hashtable 
		entries: " + h);
		// creating set view for hash table
		Set s = h.entrySet();
		// printing set entries
		System.out.println("set entries: " + s);
	}
}
//set entries: [3=Data, 2=Structure, 1=IF-AZ]