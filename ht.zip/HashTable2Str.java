// Java code illustrating toString() method
import java.util.*;
class HashTable2Str {
	public static void main(String[] arg){
		// creating a hash table
		Hashtable<Integer, String> h =
			new Hashtable<Integer, String>();
		h.put(3, "Data");
		h.put(2, "Structure");
		h.put(1, "IF-AZ");
		// String equivalent of map
		System.out.println("string equivalent" +
			" of hashtable:\n" + h.toString());
	}
}
//string equivalent of hashtable: 
//{3=Data, 2=Structure, 1=IF-AZ}