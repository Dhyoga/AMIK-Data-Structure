// Java code illustrating clear() and clone() methods 
import java.util.*; 
class HashTabledemo { 
    public static void main(String[] arg) 
    { 
        // creating a hash table 
        Hashtable<Integer, String> h = 
                      new Hashtable<Integer, String>(); 
  
        Hashtable<Integer, String> h1 = 
                      new Hashtable<Integer, String>(); 
  
        h.put(3, "IF-AZ"); 
        h.put(2, "Structure"); 
        h.put(1, "Data"); 
        // checking hash table h 
        System.out.println("after put 3 values:\n" + h); 
  
        // create a clone or shallow copy of hash table h 
        h1 = (Hashtable<Integer, String>)h.clone(); 
  
        // checking clone h1 
        System.out.println("values in clone:\n" + h1); 
  
        // clear hash table h 
        h.clear(); 
  
        // checking hash table h 
        System.out.println("after clearing: " + h); 
	}
}
/*
after put 3 values:
{3=IF-AZ, 2=Structure, 1=Data}
values in clone:
{3=IF-AZ, 2=Structure, 1=Data}
after clearing: {}
*/