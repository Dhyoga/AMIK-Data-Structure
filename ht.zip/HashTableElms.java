// Java code illustrating elements() method
import java.util.*;
class HashTableElms {
	public static void main(String[] arg){
		// creating a hash table
		Hashtable<Integer, String> h =
			new Hashtable<Integer, String>();
		h.put(3, "Data");
		h.put(2, "Structure");
		h.put(1, "IF-AZ");
		// create enumeration
		Enumeration e = h.elements();
		System.out.println("display values:");
		while (e.hasMoreElements()) {
			System.out.print(e.nextElement()+"\t");
		}System.out.println();
	}
}
/*
display values:
Data
Structure
IF-AZ
*/