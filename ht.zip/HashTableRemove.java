// Java code illustrating remove() method
import java.util.*;
class HashTableRemove {
	public static void main(String[] arg){
		// creating a hash table
		Hashtable<Integer, String> h =
			new Hashtable<Integer, String>();
		h.put(3, "Data");
		h.put(2, "Structure");
		h.put(1, "IF-AZ");
		System.out.println("values before remove: " + h);
		// remove value for 2 from Hashtable h
		h.remove(2);
		// checking Hashtable h
		System.out.println("values after remove: " + h);
	}
}
/*
values before remove: {3=Data, 2=Structure, 1=IF-AZ}
values after remove: {3=Data, 1=IF-AZ}
*/