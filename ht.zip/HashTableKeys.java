// Java code illustrating keys() method
import java.util.*;
class HashTableKeys {
	public static void main(String[] arg){
		// creating a hash table
		Hashtable<Integer, String> h =
			new Hashtable<Integer, String>();
		Hashtable<Integer, String> h1 =
			new Hashtable<Integer, String>();
		h.put(3, "Data");
		h.put(2, "Structure");
		h.put(1, "IF-AZ");
		// create enumeration
		Enumeration e1 = h.keys();
		System.out.println("display key:");
		while (e1.hasMoreElements()) {
			System.out.print(e1.nextElement()+", ");
//			System.out.println(e1.nextElement().hashCode());
		} System.out.println();
	}
}
/*
display key:
3
2
1
*/