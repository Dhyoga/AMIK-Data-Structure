// Java code illustrating keySet() method
import java.util.*;
class HashTableKeySet {
	public static void main(String[] arg){
		// creating a hash table
		Hashtable<Integer, String> h =
			new Hashtable<Integer, String>();
		h.put(3, "Data");
		h.put(2, "Structure");
		h.put(1, "IF-AZ");
		// creating set view for keys
		Set sKey = h.keySet();
		// checking key set
		System.out.println("key set: " + sKey);
	}
}
//key set: [3, 2, 1]